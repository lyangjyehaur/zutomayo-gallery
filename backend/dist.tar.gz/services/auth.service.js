import { getDB } from './db.service.js';
import crypto from 'crypto';
const defaultAuthData = { passkeys: [] };
export class AuthService {
    sessionTokens = new Set();
    generateSessionToken() {
        const token = crypto.randomBytes(32).toString('hex');
        this.sessionTokens.add(token);
        // Token 過期時間：24 小時
        setTimeout(() => {
            this.sessionTokens.delete(token);
        }, 24 * 60 * 60 * 1000);
        return token;
    }
    isValidSessionToken(token) {
        return this.sessionTokens.has(token);
    }
    async getPasskeys() {
        const db = getDB();
        const rows = db.prepare('SELECT * FROM auth_passkeys').all();
        return rows.map(r => {
            let transports;
            if (r.transports) {
                try {
                    transports = JSON.parse(r.transports);
                }
                catch (e) {
                    transports = [];
                }
            }
            return {
                id: r.id,
                publicKey: r.publicKey,
                counter: r.counter,
                transports,
                name: r.name,
                createdAt: r.createdAt
            };
        });
    }
    async savePasskey(passkey) {
        const db = getDB();
        const stmt = db.prepare('INSERT OR REPLACE INTO auth_passkeys (id, publicKey, counter, transports, name, createdAt) VALUES (?, ?, ?, ?, ?, ?)');
        stmt.run(passkey.id, passkey.publicKey, passkey.counter, passkey.transports ? JSON.stringify(passkey.transports) : null, passkey.name || null, passkey.createdAt);
    }
    async removePasskey(id) {
        const db = getDB();
        db.prepare('DELETE FROM auth_passkeys WHERE id = ?').run(id);
    }
    async setCurrentChallenge(challenge) {
        const db = getDB();
        db.prepare('INSERT OR REPLACE INTO auth_settings (key, value) VALUES (?, ?)').run('currentChallenge', challenge);
    }
    async getCurrentChallenge() {
        const db = getDB();
        const row = db.prepare('SELECT value FROM auth_settings WHERE key = ?').get('currentChallenge');
        return row ? row.value : undefined;
    }
    async getPassword() {
        const db = getDB();
        const row = db.prepare('SELECT value FROM auth_settings WHERE key = ?').get('password');
        return row ? row.value : undefined;
    }
    async setPassword(password) {
        const db = getDB();
        db.prepare('INSERT OR REPLACE INTO auth_settings (key, value) VALUES (?, ?)').run('password', password);
    }
    async updatePasskeyCounter(id, counter) {
        const db = getDB();
        db.prepare('UPDATE auth_passkeys SET counter = ? WHERE id = ?').run(counter, id);
    }
}
export const authService = new AuthService();

import { generateRegistrationOptions, verifyRegistrationResponse, generateAuthenticationOptions, verifyAuthenticationResponse } from '@simplewebauthn/server';
import { authService } from '../services/auth.service.js';
import bcrypt from 'bcrypt';
// V10 SimpleWebAuthn API 變更：不再使用 isoBase64URL，而是使用 Uint8Array 處理。
// 但為了簡化 JSON 儲存，我們將 base64URL 與 Uint8Array 進行轉換。
function bufferToBase64URL(buffer) {
    return Buffer.from(buffer).toString('base64url');
}
function base64URLToBuffer(base64url) {
    const buf = Buffer.from(base64url, 'base64url');
    const arr = new Uint8Array(buf.length);
    for (let i = 0; i < buf.length; i++)
        arr[i] = buf[i];
    return arr;
}
const rpName = 'ZUTOMAYO Gallery Admin';
const getOriginInfo = (req) => {
    const origin = req.get('origin') || process.env.EXPECTED_ORIGIN || 'http://localhost:5173';
    const rpID = process.env.RP_ID || new URL(origin).hostname;
    return { origin, rpID };
};
export const generateRegOptions = async (req, res) => {
    try {
        const { rpID } = getOriginInfo(req);
        const passkeys = await authService.getPasskeys();
        const options = await generateRegistrationOptions({
            rpName,
            rpID,
            userID: new Uint8Array(Buffer.from('admin-user-id')),
            userName: 'admin',
            attestationType: 'none',
            excludeCredentials: passkeys.map(pk => ({
                id: pk.id,
                transports: pk.transports,
            })),
        });
        await authService.setCurrentChallenge(options.challenge);
        res.json(options);
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
};
export const verifyReg = async (req, res) => {
    try {
        const body = req.body;
        const name = body.name || 'Unnamed Passkey';
        const { origin, rpID } = getOriginInfo(req);
        const expectedChallenge = await authService.getCurrentChallenge();
        if (!expectedChallenge)
            return res.status(400).json({ error: 'No active challenge' });
        const verification = await verifyRegistrationResponse({
            response: body.data,
            expectedChallenge,
            expectedOrigin: origin,
            expectedRPID: rpID,
        });
        if (verification.verified && verification.registrationInfo) {
            const { credential, credentialDeviceType, credentialBackedUp } = verification.registrationInfo;
            await authService.savePasskey({
                id: credential.id,
                publicKey: bufferToBase64URL(credential.publicKey),
                counter: credential.counter,
                transports: credential.transports,
                name,
                createdAt: new Date().toISOString()
            });
            return res.json({ success: true });
        }
        res.status(400).json({ success: false });
    }
    catch (error) {
        res.status(400).json({ error: error.message });
    }
};
export const generateAuthOptions = async (req, res) => {
    try {
        const { rpID } = getOriginInfo(req);
        const passkeys = await authService.getPasskeys();
        if (passkeys.length === 0) {
            return res.status(400).json({ error: '系統中沒有註冊任何 Passkey' });
        }
        const options = await generateAuthenticationOptions({
            rpID,
            allowCredentials: passkeys.map(pk => ({
                id: pk.id,
                transports: pk.transports,
            })),
        });
        await authService.setCurrentChallenge(options.challenge);
        res.json(options);
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
};
export const verifyAuth = async (req, res) => {
    try {
        const body = req.body;
        const { origin, rpID } = getOriginInfo(req);
        const expectedChallenge = await authService.getCurrentChallenge();
        if (!expectedChallenge)
            return res.status(400).json({ error: 'No active challenge' });
        const passkeys = await authService.getPasskeys();
        const passkey = passkeys.find(pk => pk.id === body.id);
        if (!passkey)
            return res.status(400).json({ error: '找不到對應的 Passkey' });
        const verification = await verifyAuthenticationResponse({
            response: body,
            expectedChallenge,
            expectedOrigin: origin,
            expectedRPID: rpID,
            credential: {
                id: passkey.id,
                publicKey: base64URLToBuffer(passkey.publicKey),
                counter: passkey.counter,
                transports: passkey.transports,
            },
        });
        if (verification.verified) {
            await authService.updatePasskeyCounter(passkey.id, verification.authenticationInfo.newCounter);
            const isDefaultPassword = !(await authService.getPassword());
            // 給前端一個安全的授權 token，以免把 hash 傳出去
            const token = authService.generateSessionToken();
            return res.json({ success: true, token, isDefaultPassword });
        }
        res.status(400).json({ success: false });
    }
    catch (error) {
        res.status(400).json({ error: error.message });
    }
};
export const listPasskeys = async (req, res) => {
    const passkeys = await authService.getPasskeys();
    res.json(passkeys.map(pk => ({ id: pk.id, name: pk.name, createdAt: pk.createdAt })));
};
export const removePasskey = async (req, res) => {
    await authService.removePasskey(req.params.id);
    res.json({ success: true });
};
export const changePassword = async (req, res) => {
    const { oldPassword, newPassword } = req.body;
    const storedPassword = await authService.getPassword();
    if (storedPassword) {
        // 已經有設定過密碼，必須驗證舊密碼
        if (!oldPassword) {
            return res.status(400).json({ error: '請輸入舊密碼' });
        }
        const isMatch = await bcrypt.compare(oldPassword, storedPassword);
        if (!isMatch) {
            return res.status(400).json({ error: '舊密碼驗證失敗' });
        }
    }
    else {
        // 沒有設定過密碼，如果前端有傳舊密碼過來，才去驗證預設密碼 (通常前端如果發現是預設密碼，不會強制要求填寫舊密碼)
        if (oldPassword) {
            const currentPassword = process.env.ADMIN_PASSWORD || 'zutomayo';
            if (oldPassword !== currentPassword) {
                return res.status(400).json({ error: '舊密碼驗證失敗' });
            }
        }
    }
    if (!newPassword || typeof newPassword !== 'string' || newPassword.length < 4) {
        return res.status(400).json({ error: '密碼無效，至少需要4個字元' });
    }
    if (newPassword === 'zutomayo') {
        return res.status(400).json({ error: '不能修改回初始密碼' });
    }
    const saltRounds = 10;
    const hashedPassword = await bcrypt.hash(newPassword, saltRounds);
    await authService.setPassword(hashedPassword);
    res.json({ success: true });
};
